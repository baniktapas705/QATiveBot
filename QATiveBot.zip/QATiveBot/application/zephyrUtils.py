import requests
import jwt
import time


# Replace these variables with your details
JIRA_BASE_URL = ""
API_ENDPOINT = f"{JIRA_BASE_URL}/rest/zapi/latest/import/feature"
#Zephyr Credentials
ACCESS_KEY = ""
SECRET_KEY = ""
#JIRA Account ID
ACCOUNT_ID = ""
# Path to the feature file where the chatbot response will be written
FEATURE_FILE_PATH = ""

# Generate JWT token
def generate_jwt(api_endpoint, access_key, secret_key, account_id):
    payload = {
        'sub': account_id,
        'qsh': api_endpoint.split('?')[0],  # Extract path for qsh
        'iss': access_key,
        'iat': int(time.time()),
        'exp': int(time.time()) + 3600
    }
    token = jwt.encode(payload, secret_key, algorithm='HS256')
    return token

# JWT token generation
jwt_token = generate_jwt(API_ENDPOINT, ACCESS_KEY, SECRET_KEY, ACCOUNT_ID)
print("Generated JWT Token:", jwt_token)

# Read the feature file
with open(FEATURE_FILE_PATH, 'r') as file:
    feature_content = file.read()

# API request headers
headers = {
    'Authorization': f'JWT {jwt_token}',
    'zapiAccessKey': ACCESS_KEY,
    'Content-Type': 'text/plain'
}

# Making the API request
response = requests.post(API_ENDPOINT, headers=headers, data=feature_content)

# Check response
if response.status_code == 200:
    print("Feature file imported successfully.")
else:
    print(f"Failed to import feature file. Status code: {response.status_code}")
    print(response.text)
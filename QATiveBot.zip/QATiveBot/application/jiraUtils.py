
import requests
import json
import base64


def get_jira_auth_token(EMAIL, API_TOKEN):
    # Encode email and API token in Base64
    auth_string = f'{EMAIL}:{API_TOKEN}'
    auth_bytes = auth_string.encode('utf-8')
    auth_base64 = base64.b64encode(auth_bytes).decode('utf-8')
    return auth_base64



def create_jira_story(JIRA_URL,email, api_token, summary, description, project_key=None, parent_key=None, labels=None, components=None):
    create_issue_url = f'{JIRA_URL}/rest/api/latest/issue'

    print("Creating JIRA story...")  # Debug log
    print(f"Summary: {summary}, Description: {description}, Project Key: {project_key}")  # Debug log

    issue_data = {
        "fields": {
            "project": {
                "key": project_key
            },
            "summary": summary,
            "description": description,
            "issuetype": {
                "name": "Story"
            },
            "labels": labels if labels else [],
            "components": [{"name": comp} for comp in components] if components else [],
            "parent": {
                "key": parent_key
            }
        }
    }

    try:
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Basic {get_jira_auth_token(email, api_token)}'
        }
        response = requests.post(create_issue_url, headers=headers, data=json.dumps(issue_data))
        print(f"Response Status Code: {response.status_code}")  # Debug log
        print(f"Response Text: {response.text}")  # Debug log

        if response.status_code == 201:
            print("User story created successfully.")
            issue_key = response.json()['key']
            return issue_key
        else:
            print(f"Failed to create user story: {response.status_code}")
            print(response.json())
            return None
    except Exception as e:
        print(f"Exception during JIRA story creation: {e}")
        return None


def add_attachment_to_jira_story(JIRA_URL,email, api_token, issue_key, file_path):
    add_attachment_url = f'{JIRA_URL}/rest/api/latest/issue/{issue_key}/attachments'

    attachment_headers = {
        'X-Atlassian-Token': 'no-check',
        'Authorization': f'Basic {get_jira_auth_token(email, api_token)}'
    }
    if '.txt' in file_path:
        files = {
            'file': ('TestCase.txt', open(file_path, 'rb'))
        }
    elif '.feature' in file_path:
        files = {
            'file': ('BDD.feature', open(file_path, 'rb'))
        }

    try:
        response = requests.post(add_attachment_url, headers=attachment_headers, files=files)
        print(f"Response Status Code: {response.status_code}")  # Debug log
        print(f"Response Text: {response.text}")  # Debug log

        if response.status_code == 200:
            print("Attachment added successfully.")
            return True
        else:
            print(f"Failed to add attachment: {response.status_code}")
            print(response.json())
            return False
    except Exception as e:
        print(f"Exception during attachment upload: {e}")
        return False

def get_issue_id_by_key(email, api_token, issue_key, jira_url):
    url = f"{jira_url}/rest/api/latest/issue/{issue_key}"

    try:
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Basic {get_jira_auth_token(email, api_token)}'
        }
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception for 4xx or 5xx status codes

        res_obj = response.json()
        print(res_obj)

        if 'id' in res_obj:
            issue_id = res_obj['id']
            return issue_id

        print(f"Could not find IssueId for test: [{issue_key}]")
        return 0

    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return 0
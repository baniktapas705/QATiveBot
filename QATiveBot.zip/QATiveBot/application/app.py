import os
import streamlit as st
import docx
import pdfplumber
from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain_community.chat_models import ChatOpenAI
from jiraUtils import create_jira_story, add_attachment_to_jira_story


# Configuration
PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
RESOURCES_DIR = os.path.join(PROJECT_ROOT, 'resources')
FEATURE_FILE_PATH = os.path.join(RESOURCES_DIR, "BDD.feature")
TEXT_FILE_PATH = os.path.join(RESOURCES_DIR, "Response.txt")

# ChatGPT API Key
#OPENAI_API_KEY = ""

# Streamlit Configs
ST_PAGE_CONFIG = {"layout": "wide", "page_title": "QATive Assistant", "page_icon": "resources/logo.png"}
CUSTOM_CSS = """
<style>
.stApp {
    background-color: white; /* White color */
    padding: 10px;
    background-size: auto;
    background-repeat: no-repeat;
    background-position: right bottom;
    font-family: Arial, sans-serif;
}

.stApp h1 {
    font-size: 36px;
    color: #E4002B; /* Red color */
    text-align: center;
    margin-top: 20px;
}

.stSidebar {
    background-color: #E4002B; /* Red color */
}

.stSidebar .stFileUploader, .stSidebar .stTextInput, .stSidebar .stTextArea {
    margin-bottom: 20px;
    color: black; /* Black color */
}

.url-container {
    position: fixed;
    bottom: 10px;
    left: 10px;
    font-size: 14px;
    color: #000000; /* Black color */
}

footer {
    visibility: hidden;
}
</style>
"""

# Initialization
st.set_page_config(**ST_PAGE_CONFIG)
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)
st.title("QATive Assistant")

def initialize_session_state():
    """
    Initializes the session state variables.
    """
    if 'response' not in st.session_state:
        st.session_state['response'] = ""
    if 'feature_file_saved' not in st.session_state:
        st.session_state['feature_file_saved'] = False
    if 'text_file_saved' not in st.session_state:
        st.session_state['text_file_saved'] = False
    if 'issue_key' not in st.session_state:
        st.session_state['issue_key'] = None

initialize_session_state()

def extract_text_from_docx(file):
    """
    Extracts text from a docx file.

    Parameters:
    file (UploadedFile): The docx file to extract text from.

    Returns:
    str: The extracted text.
    """
    document = docx.Document(file)
    return '\n'.join([para.text for para in document.paragraphs])


def extract_text_and_tables_from_docx(file):
    """
    Extracts text and tables from a docx file.

    Parameters:
    file (UploadedFile): The docx file to extract text and tables from.

    Returns:
    tuple: The extracted text and tables.
    """
    doc = docx.Document(file)

    # Extract plain text
    text = '\n'.join([para.text for para in doc.paragraphs])

    # Extract table data
    tables = []
    for table in doc.tables:
        table_data = []
        for row in table.rows:
            row_data = [cell.text.strip() for cell in row.cells]
            table_data.append(row_data)
        tables.append(table_data)

    return text, tables

def extract_text_from_pdf(file):
    """
    Extracts text from a pdf file.

    Parameters:
    file (UploadedFile): The pdf file to extract text from.

    Returns:
    str: The extracted text.
    """
    pdf_reader = PdfReader(file)
    return "".join([page.extract_text() for page in pdf_reader.pages])


def extract_text_and_tables_from_pdf(file):
    """
    Extracts text and tables from a pdf file.

    Parameters:
    file (UploadedFile): The pdf file to extract text and tables from.

    Returns:
    tuple: The extracted text and tables.
    """
    text = ""
    tables = []

    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            # Extract plain text
            text += page.extract_text() or ""

            # Extract tables
            page_tables = page.extract_tables()
            tables.extend(page_tables)

    return text, tables

def format_content(text, tables):
    """
    Formats the extracted text and tables.

    Parameters:
    text (str): The extracted text.
    tables (list): The extracted tables.

    Returns:
    str: The formatted content.
    """
    formatted_content = text

    for table in tables:
        formatted_content += "\n\n"
        for row in table:
            formatted_content += "\t".join(row) + "\n"

    return formatted_content

def break_text_into_chunks(text):
    """
    Breaks the text into chunks.

    Parameters:
    text (str): The text to break into chunks.

    Returns:
    list: The chunks of text.
    """
    text_splitter = RecursiveCharacterTextSplitter(separators="\n", chunk_size=1000, chunk_overlap=100, length_function=len)
    return text_splitter.split_text(text)

def generate_embeddings_and_vector_store(chunks):
    """
    Generates embeddings and a vector store from the chunks of text.

    Parameters:
    chunks (list): The chunks of text.

    Returns:
    VectorStore: The generated vector store.
    """
    embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
    return FAISS.from_texts(chunks, embeddings)

def interactive_chatbot(vector_store, llm, user_question):
    """
    Interacts with the chatbot.

    Parameters:
    vector_store (VectorStore): The vector store.
    llm (ChatOpenAI): The chatbot model.
    user_question (str): The user's question.

    Returns:
    str: The chatbot's response.
    """
    match = vector_store.similarity_search(user_question)
    chain = load_qa_chain(llm, chain_type="stuff")
    return chain.run(input_documents=match, question=user_question)

def save_response_to_file(file_path, response):
    """
    Saves the chatbot's response to a file.

    Parameters:
    file_path (str): The path to the file to save the response in.
    response (str): The chatbot's response.
    """
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(response)

def handle_file_upload(file):
    """
    Handles the upload of a file.

    Parameters:
    file (UploadedFile): The file to handle.

    Returns:
    str: The formatted content of the file.
    """
    if file.type == "application/pdf":
        text, tables = extract_text_and_tables_from_pdf(file)
    elif file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        text, tables = extract_text_and_tables_from_docx(file)
    else:
        st.error("Unsupported file format. Please upload PDF or Word documents.")
        return "", []

    formatted_content = format_content(text, tables)
    return formatted_content

def handle_uploaded_files(files):
    """
    Handles the upload of multiple files.

    Parameters:
    files (list): The files to handle.

    Returns:
    VectorStore: The vector store generated from the file contents.
    """
    all_text = ""

    for file in files:
        formatted_content = handle_file_upload(file)
        all_text += "\n\n" + formatted_content

    chunks = break_text_into_chunks(all_text)
    return generate_embeddings_and_vector_store(chunks)

def display_response(response):
    """
    Displays the chatbot's response in different formats based on its type.

    Parameters:
    response (str): The chatbot's response.
    """
    #I want to check the condition whether the response is in Gherkin or not if yes then use st.code
    if "Feature:" in response and "Scenario:" in response and "Given" in response and "When" in response and "Then" in response:
        st.code(response, language="gherkin")
    else:
        st.write(response)


def extract_feature_name(file_path):
    """
    Extracts the feature name from a file.

    Parameters:
    file_path (str): The path to the file to extract the feature name from.

    Returns:
    str: The extracted feature name.
    """
    with open(file_path, 'r') as file:
        for line in file:
            if line.startswith('Feature:'):
                return line.split(':', 1)[1].strip()

def create_and_upload_jira_story(file_path, file_type,email, api_token, project_key=None, parent_key=None, labels='BDD_Feature', components=None):
    """
    Creates a JIRA story and uploads a file to it.

    Parameters:
    file_path (str): The path to the file to upload.
    file_type (str): The type of the file to upload.
    email (str): The user's email.
    api_token (str): The user's JIRA API token.
    project_key (str, optional): The JIRA project key. Defaults to None.
    parent_key (str, optional): The JIRA parent key. Defaults to None.
    labels (str, optional): The JIRA labels. Defaults to 'BDD_Feature'.
    components (str, optional): The JIRA components. Defaults to None.
    """
    try:
        st.write("Attempting to create JIRA story...")
        if file_type == 'feature':
            issue_key = create_jira_story(JIRA_URL,email, api_token, extract_feature_name(file_path), "This is an Automation created Story - Need to Update the 'Description' field", project_key, parent_key, labels, components)
        elif file_type == 'text':
            issue_key = create_jira_story(JIRA_URL, email, api_token,"This is an Automation created Story - Need to Update the 'Summary' field" , "This is an Automation created Story - Need to Update the 'Description' field", project_key, parent_key, labels, components)

        st.write(f"Received issue key: {issue_key}")
        if issue_key:
            st.write(f"JIRA Issue Key Created: {issue_key}")
            st.session_state['issue_key'] = issue_key
            try:
                st.write(f"Attempting to upload {file_type} file to JIRA story...")
                if add_attachment_to_jira_story(JIRA_URL, email, api_token,issue_key, file_path):
                    st.success(f"{file_type} file uploaded to JIRA story: {issue_key}")
                else:
                    st.error(f"Failed to upload the {file_type} file to JIRA.")
            except Exception as e:
                st.error(f"Error during file upload to JIRA: {e}")
        else:
            st.error("Failed to create JIRA story.")
    except Exception as e:
        st.error(f"Error during JIRA story creation: {e}")

# Sidebar for upload PDF and Word files
with st.sidebar:
    # Get OpenAI API Key from user input
    OPENAI_API_KEY = st.text_input("Enter your OpenAI API Key",type="password")
    st.markdown("<div class='stSidebar'>", unsafe_allow_html=True)
    st.title("Upload Documents")
    files = st.file_uploader("Upload PDF or Word documents Only", type=["pdf", "docx"], accept_multiple_files=True)
    # Get JIRA_URL from user input
    JIRA_URL = st.text_input("Enter your JIRA URL:")

    project_key = st.text_input("Mention JIRA Project Key")
    email = st.text_input("Your Email")
    jiraApiKey = st.text_input("Mention Your JIRA API Key",type="password")

    jiraEpicName_input = st.text_input("JIRA Epic ID")
    jiraEpicName = jiraEpicName_input if jiraEpicName_input else None

    labels_input = st.text_area("JIRA Labels (comma-separated)")
    components_input = st.text_area("JIRA Component Names (comma-separated)")
    st.markdown("</div>", unsafe_allow_html=True)
    # Convert the comma-separated string inputs into arrays
    labels = [label.strip() for label in labels_input.split(",") if label.strip()]
    components = [component.strip() for component in components_input.split(",") if component.strip()]



if files:
    vector_store = handle_uploaded_files(files)
    user_question = st.text_input("Type your question here:")
    llm = ChatOpenAI(openai_api_key=OPENAI_API_KEY, temperature=0, max_tokens=4500, model_name="gpt-4")

    if st.button("Ask a Question!") and user_question:
        st.session_state['response'] = interactive_chatbot(vector_store, llm, user_question)

    if st.session_state['response']:
        print(st.session_state['response'])
        display_response(st.session_state['response'])

        if st.button("Save Response to Feature File"):
            save_response_to_file(FEATURE_FILE_PATH, st.session_state['response'])
            st.success(f"File saved successfully: {FEATURE_FILE_PATH}")
            st.session_state['feature_file_saved'] = True

        if st.button("Save Response to Text File"):
            save_response_to_file(TEXT_FILE_PATH, st.session_state['response'])
            st.success(f"File saved successfully: {TEXT_FILE_PATH}")
            st.session_state['text_file_saved'] = True

        if st.session_state['feature_file_saved']:
            if st.button("Upload Feature File to New JIRA Story"):
                create_and_upload_jira_story(FEATURE_FILE_PATH, "feature",email, jiraApiKey, project_key, jiraEpicName, labels, components)

            with st.form(key='upload_form_feature_file'):
                issue_key = st.text_input(
                    "Type your exact JIRA Story ID if you want to upload this feature file to an existing JIRA Story rather creating new one:")
                submit_button = st.form_submit_button(label='Submit')
                if submit_button:
                    if issue_key:
                        try:
                            st.write("Attempting to upload feature file to JIRA story...")
                            if add_attachment_to_jira_story(JIRA_URL, email, jiraApiKey, issue_key, FEATURE_FILE_PATH):
                                st.success(f"Feature file uploaded to JIRA story: {issue_key}")
                            else:
                                st.error("Failed to upload the feature file to JIRA.")
                        except Exception as e:
                            st.error(f"Error during file upload to JIRA: {e}")
                    else:
                        st.warning("Please enter a valid JIRA Story ID before submitting.")

        if st.session_state['text_file_saved']:
            if st.button("Upload Text File to New JIRA Story"):
                create_and_upload_jira_story(TEXT_FILE_PATH, "text",email, jiraApiKey, project_key, jiraEpicName, labels, components)

            with st.form(key='upload_form_text_file'):
                issue_key = st.text_input(
                    "Type your exact JIRA Story ID if you want to upload this text file to an existing JIRA Story rather creating new one:")
                submit_button = st.form_submit_button(label='Submit')
                if submit_button:
                    if issue_key:
                        try:
                            st.write("Attempting to upload text file to JIRA story...")
                            if add_attachment_to_jira_story(JIRA_URL, email, jiraApiKey, issue_key, TEXT_FILE_PATH):
                                st.success(f"Text file uploaded to JIRA story: {issue_key}")
                            else:
                                st.error("Failed to upload the text file to JIRA.")
                        except Exception as e:
                            st.error(f"Error during file upload to JIRA: {e}")
                    else:
                        st.warning("Please enter a valid JIRA Story ID before submitting.")
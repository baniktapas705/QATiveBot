#!/bin/bash
BASE_DIR=$(dirname "$0")
streamlit run $BASE_DIR/application/app.py